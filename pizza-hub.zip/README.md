#Run this command once to regenerate optimized autoload files:
composer dump-autoload -o
